# ============================================================
#  terraform.tfvars
#  Supplies actual values for the variables declared in
#  variables.tf. This is the only file you change between
#  environments (or use workspaces/separate tfvars files).
#
#  IMPORTANT RULES:
#  1. Never commit secrets (passwords, tokens) to git — use
#     environment variables or a secrets manager instead.
#  2. Add terraform.tfvars to .gitignore if it holds secrets.
#  3. For multiple environments, create separate files:
#     dev.tfvars, staging.tfvars, prod.tfvars
#     and apply with: terraform apply -var-file="prod.tfvars"
# ============================================================

aws_region   = "ap-south-1"
project_name = "sk-tf"
environment  = "dev"

# Networking
vpc_cidr      = "10.1.0.0/16"
subnet_1_cidr = "10.1.0.0/24"
subnet_2_cidr = "10.1.1.0/24"
az_1          = "ap-south-1a"
az_2          = "ap-south-1b"

# Compute
ami_id          = "ami-05d2d839d4f73aafb"
instance_type   = "t2.nano"
key_name        = "tf-instance-key"
public_key_path = "~/.ssh/id_rsa.pub"

# Storage — must be globally unique across all AWS accounts
s3_bucket_name = "sk-tf-app-bucket-2024"
